<script>
    var symptoma_mode = 'CORONA';
    var symptoma_integration = 'inline';
</script>
<script id="symptoma-integration" type="text/javascript" src="https://www.symptoma.net/en/embed.js"></script>